import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ButtonGroup;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JButton;
import javax.swing.*;


class OnlineTest extends JFrame implements ActionListener{
 
 JLabel label;
 JRadioButton radioButton[]=new JRadioButton[5];
 JButton btnNext, btnBookmark;
 ButtonGroup bg;
 int count=0,current=0,x=1,y=1,now=0;
 int m[]=new int[10];
 
 OnlineTest(String message){
   
   super(message);
   label=new JLabel();
   add(label);
   bg=new ButtonGroup();
   int i;
   for(i=0;i<5;i++){
   
   radioButton[i]=new JRadioButton();
   add(radioButton[i]);
   bg.add(radioButton[i]);
   
    }
  btnNext=new JButton("Save and Next");
  btnBookmark=new JButton("Skip");
  btnNext.addActionListener(this);
  btnBookmark.addActionListener(this);
  add(btnNext);
  add(btnBookmark);
  set();
  label.setBounds(30,40,500,20);
  radioButton[0].setBounds(50,80,200,20);
  radioButton[1].setBounds(50,110,200,20);
  radioButton[2].setBounds(50,140,200,20);
  radioButton[3].setBounds(50,170,200,20);
  btnNext.setBounds(90,240,130,30);
  btnBookmark.setBounds(270,240,100,30);
  setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  setLayout(null);
  setLocation(250,100);
  setVisible(true);
  setSize(750,450);
 
  }

  void set()
  {
   radioButton[4].setSelected(true);
   if(current==0){
    label.setText("Que1:  What does the operator >>>> do?");
    radioButton[0].setText("Zero fill Right shift");//correct
    radioButton[1].setText("Zero fill Left shift");
    radioButton[2].setText("Left shift operator");
    radioButton[3].setText("Right shift operator");
    }
   if(current==1){
     label.setText("Que2:  Which of the below is not a Java Profiler?");
      radioButton[0].setText(" Eclipse Profiler");
      radioButton[1].setText(" JProfiler");
      radioButton[2].setText("JConsole");
      radioButton[3].setText("JVM");//correct
    }
    if(current==2){
     label.setText("Que3:  Which of these packages contains the exception Stack Overflow in Java?");
      radioButton[0].setText("java.io");
      radioButton[1].setText(" java.system");
      radioButton[2].setText("java.lang");//correct
      radioButton[3].setText("java.util");
    }
    if(current==3){
     label.setText("Que4:   Which class provides system independent server side implementation?");
      radioButton[0].setText("Server");
      radioButton[1].setText("ServerReader");
      radioButton[2].setText("Socket");
      radioButton[3].setText("ServerSocket");//correct
    }
    if(current==4){
    label.setText("Que5:  Which of the following is not introduced with Java 8?");
    radioButton[0].setText("Lambda Expression");
    radioButton[1].setText("Spliterator");
    radioButton[2].setText("Serialization");//correct
    radioButton[3].setText("Stream API");
    }
    if(current==5){
     label.setText("Que6:   Which of the following is not a state of object in Hibernate?");
      radioButton[0].setText("Attached()");
      radioButton[1].setText("Detached()");//correct
      radioButton[2].setText("Pesistent()");
      radioButton[3].setText("Transient()");
    }
    if(current==6){
     label.setText("Que7:   An interface with no fields or methods is known as a ______.");
      radioButton[0].setText("Runnable Interface");
      radioButton[1].setText("Marker Interface");//correct
      radioButton[2].setText("Abstract Interface");
      radioButton[3].setText("CharSequence Interface");
    }
     if(current==7){
     label.setText("Que8:   Which of the following is a mutable class in java?");
      radioButton[0].setText("java.lang.String");
      radioButton[1].setText("java.lang.Short");
      radioButton[2].setText("java.lang.Byte");
      radioButton[3].setText("java.lang.StringBuilder");//correct
    }
     if(current==8){
     label.setText("Que9:   What is meant by the classes and objects that dependents on each other?");
      radioButton[0].setText("Tight Coupling");//correct
      radioButton[1].setText("Loose Coupling");
      radioButton[2].setText("Cohesion");
      radioButton[3].setText("None of the above");
    }
     if(current==9){
     label.setText("Que10:   What is the default encoding for an OutputStreamWriter?");
      radioButton[0].setText("UTF-8");
      radioButton[1].setText("Default encoding of the host platform");//correct
      radioButton[2].setText("UTF-12");
      radioButton[3].setText("None of the above");
    }
label.setBounds(30,40,500,20);
int i,j;
for(i=0,j=0; i<=90;i+=30,j++)
    radioButton[j].setBounds(50,80+i,200,20);
}

boolean check(){
  if(current==0)
     return(radioButton[0].isSelected());
  if(current==1)
     return(radioButton[3].isSelected());
  if(current==2)
     return(radioButton[2].isSelected());
  if(current==3)
     return(radioButton[3].isSelected());
  if(current==4)
     return(radioButton[2].isSelected());
  if(current==5)
     return(radioButton[1].isSelected());
  if(current==6)
     return(radioButton[1].isSelected());
  if(current==7)
     return(radioButton[3].isSelected());
  if(current==8)
     return(radioButton[0].isSelected());
  if(current==9)
     return(radioButton[1].isSelected());
  return false;
}

@Override
public void actionPerformed(ActionEvent e){
  if(e.getSource()==btnNext){
     if(check())
       count=count+1;
     current++;
     set();
     if(current==9){
       btnNext.setEnabled(false);
       btnBookmark.setText("Result");
     }
   }
   if(e.getActionCommand().equals("Skip")){
   JButton bk=new JButton("Skipped "+x);
   bk.setBounds(510,40+30*x,100,30);
   add(bk);
   bk.addActionListener(this);
   m[x]=current;
   x++;
   current++;
   set();
   if(current==9)
      btnBookmark.setText("Result");
   setVisible(false);
   setVisible(true);

   }
   int i;
   for(i=0,y=1;i<x;i++,y++){
     if(e.getActionCommand().equals("Skip"+y)){
      if(check())
        count=count+1;
      now=current;
      current=m[y];
      set();
      ((JButton) e.getSource()).setEnabled(false);
      current=now;
     }
   }
   if(e.getActionCommand().equals("Result")){
      if(check())
        count=count+1;
      current++;
      JOptionPane.showMessageDialog(this,"correct answer="+count);
      System.exit(0);
   }
}
public static void main(String args[])
{
 new OnlineTest("Online Test App");
}

}






 